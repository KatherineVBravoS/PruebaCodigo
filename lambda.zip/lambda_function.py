import json
import urllib.request

def lambda_handler(event, context):
    api_url = "https://dn8mlk7hdujby.cloudfront.net/interview/insurance/58"
    
    try:
        response = urllib.request.urlopen(api_url)
        data = json.load(response)
        return {
            'statusCode': 200,
            'body': json.dumps(data)
        }
    except urllib.error.URLError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"error": str(e)})
        }
